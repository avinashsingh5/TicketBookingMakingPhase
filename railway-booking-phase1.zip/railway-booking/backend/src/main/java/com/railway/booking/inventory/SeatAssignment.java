package com.railway.booking.inventory;

import com.railway.booking.reservation.Reservation;
import com.railway.booking.ticket.Ticket;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * The CURRENT hold or confirmed allocation of a seat. The seat's id is also this table's
 * primary key, so the database itself guarantees "one active assignment per seat".
 * Rows are deleted when a seat is released; history stays on the tickets.
 */
@Entity
@Table(name = "seat_assignments")
@Getter @Setter @NoArgsConstructor
public class SeatAssignment {

    @Id
    @Column(name = "seat_id", length = 36)
    private String seatId;                    // copied from 'seat' by @MapsId

    @MapsId
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "seat_id")
    private TripSeat seat;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "reservation_id", nullable = false)
    private Reservation reservation;

    /** Null while the seat is held before the ticket row exists; set afterwards. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ticket_id")
    private Ticket ticket;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private AssignmentStatus status;

    /** Required while HELD; a hold that passed this time can no longer be confirmed. */
    @Column(name = "hold_expires_at")
    private Instant holdExpiresAt;
}
