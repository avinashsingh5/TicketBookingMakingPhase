package com.railway.booking.inventory;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

/** One physical seat of a trip class, e.g. B1-21. Rows here are permanent inventory. */
@Entity
@Table(name = "trip_seats")
@Getter @Setter @NoArgsConstructor
public class TripSeat {

    @Id @UuidGenerator
    @Column(name = "seat_id", length = 36, updatable = false)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "class_id", nullable = false)
    private TripClass tripClass;

    @NotBlank
    @Column(name = "seat_number", nullable = false, length = 20)
    private String seatNumber;
}
