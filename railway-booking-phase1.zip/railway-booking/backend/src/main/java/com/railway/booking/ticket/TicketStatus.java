package com.railway.booking.ticket;

public enum TicketStatus {
    PENDING, CONFIRMED, CANCELLED
}
