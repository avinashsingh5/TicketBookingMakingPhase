package com.railway.booking.trip;

import com.railway.booking.train.Train;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.Instant;

/** One scheduled run of a train. Times are stored in UTC. */
@Entity
@Table(name = "trips")
@Getter @Setter @NoArgsConstructor
public class Trip {

    @Id @UuidGenerator
    @Column(name = "trip_id", length = 36, updatable = false)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "train_id", nullable = false)
    private Train train;

    @NotNull
    @Column(name = "departure_at", nullable = false)
    private Instant departureAt;

    @NotNull
    @Column(name = "arrival_at", nullable = false)
    private Instant arrivalAt;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TripStatus status = TripStatus.SCHEDULED;
}
