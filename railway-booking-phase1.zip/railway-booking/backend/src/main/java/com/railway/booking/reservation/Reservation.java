package com.railway.booking.reservation;

import com.railway.booking.inventory.TripClass;
import com.railway.booking.ticket.Ticket;
import com.railway.booking.user.User;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UuidGenerator;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/** One booking: one customer, one trip class, one or more passenger tickets. */
@Entity
@Table(name = "reservations")
@Getter @Setter @NoArgsConstructor
public class Reservation {

    @Id @UuidGenerator
    @Column(name = "reservation_id", length = 36, updatable = false)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "class_id", nullable = false)
    private TripClass tripClass;

    /** Generated only after payment succeeds. */
    @Column(length = 10)
    private String pnr;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private ReservationStatus status = ReservationStatus.PENDING_PAYMENT;

    /** The ORIGINAL booking amount. Never reduced by cancellations (refunds live in cancellation_items). */
    @NotNull @DecimalMin("0.00")
    @Column(name = "total_amount", nullable = false, precision = 12, scale = 2)
    private BigDecimal totalAmount;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "confirmed_at")
    private Instant confirmedAt;

    // Read-side convenience only; tickets are created through the ticket repository/service.
    @OneToMany(mappedBy = "reservation")
    private List<Ticket> tickets = new ArrayList<>();
}
