package com.railway.booking.cancellation;

public enum CancellationStatus {
    PENDING, COMPLETED, FAILED
}
