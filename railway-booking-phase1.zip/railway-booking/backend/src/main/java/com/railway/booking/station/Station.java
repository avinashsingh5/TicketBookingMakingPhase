package com.railway.booking.station;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

@Entity
@Table(name = "stations")
@Getter @Setter @NoArgsConstructor
public class Station {

    @Id @UuidGenerator
    @Column(name = "station_id", length = 36, updatable = false)
    private String id;

    @NotBlank @Size(max = 10)
    @Column(name = "station_code", nullable = false, length = 10)
    private String code;                      // e.g. NDLS, CSMT

    @NotBlank @Size(max = 100)
    @Column(name = "station_name", nullable = false, length = 100)
    private String name;

    @NotBlank @Size(max = 100)
    @Column(nullable = false, length = 100)
    private String city;

    @NotBlank @Size(max = 100)
    @Column(nullable = false, length = 100)
    private String state;

    /** Stations are deactivated, never deleted, so old trips keep working. */
    @Column(name = "is_active", nullable = false)
    private boolean active = true;
}
