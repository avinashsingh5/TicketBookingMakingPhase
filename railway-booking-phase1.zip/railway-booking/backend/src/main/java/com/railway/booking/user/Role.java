package com.railway.booking.user;

public enum Role {
    CUSTOMER, ADMIN
}
