package com.railway.booking.trip;

public enum TripStatus {
    SCHEDULED, COMPLETED, CANCELLED
}
