package com.railway.booking.inventory;

public enum AssignmentStatus {
    HELD, CONFIRMED
}
