package com.railway.booking.cancellation;

import com.railway.booking.reservation.Reservation;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UuidGenerator;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/** One customer action: "cancel these tickets". Its items hold the per-ticket refund. */
@Entity
@Table(name = "cancellation_requests")
@Getter @Setter @NoArgsConstructor
public class CancellationRequest {

    @Id @UuidGenerator
    @Column(name = "cancel_request_id", length = 36, updatable = false)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "reservation_id", nullable = false)
    private Reservation reservation;

    /** Status of the cancellation itself (tickets/seats). The refund payment has its own status. */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private CancellationStatus status = CancellationStatus.PENDING;

    @CreationTimestamp
    @Column(name = "requested_at", nullable = false, updatable = false)
    private Instant requestedAt;

    @Column(name = "completed_at")
    private Instant completedAt;

    @OneToMany(mappedBy = "cancellationRequest")
    private List<CancellationItem> items = new ArrayList<>();
}
