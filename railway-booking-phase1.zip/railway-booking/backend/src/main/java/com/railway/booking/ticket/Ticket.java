package com.railway.booking.ticket;

import com.railway.booking.inventory.TripSeat;
import com.railway.booking.reservation.Reservation;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UuidGenerator;

import java.math.BigDecimal;
import java.time.Instant;

/** One passenger's ticket. Never deleted: a cancelled ticket keeps its status and seat for history. */
@Entity
@Table(name = "tickets")
@Getter @Setter @NoArgsConstructor
public class Ticket {

    @Id @UuidGenerator
    @Column(name = "ticket_id", length = 36, updatable = false)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "reservation_id", nullable = false)
    private Reservation reservation;

    @NotBlank @Size(max = 100)
    @Column(name = "passenger_name", nullable = false, length = 100)
    private String passengerName;

    @Min(0) @Max(120)
    @Column(name = "passenger_age", nullable = false)
    private int passengerAge;

    @NotBlank @Size(max = 20)
    @Column(name = "passenger_gender", nullable = false, length = 20)
    private String passengerGender;

    /**
     * Historical seat. Several tickets may point to the same seat over time (after a
     * cancellation the seat is re-sold), so there is deliberately NO unique constraint.
     * The service layer must check that this seat belongs to reservation.tripClass.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "seat_id")
    private TripSeat seat;

    @NotNull @DecimalMin("0.00")
    @Column(name = "fare_paid", nullable = false, precision = 12, scale = 2)
    private BigDecimal farePaid;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TicketStatus status = TicketStatus.PENDING;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
}
