package com.railway.booking.reservation;

public enum ReservationStatus {
    PENDING_PAYMENT, CONFIRMED, PARTIALLY_CANCELLED, CANCELLED
}
