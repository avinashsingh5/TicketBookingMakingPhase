package com.railway.booking.train;

import com.railway.booking.station.Station;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

@Entity
@Table(name = "trains")
@Getter @Setter @NoArgsConstructor
public class Train {

    @Id @UuidGenerator
    @Column(name = "train_id", length = 36, updatable = false)
    private String id;

    @NotBlank @Size(max = 10)
    @Column(name = "train_number", nullable = false, length = 10)
    private String trainNumber;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "source_station_id", nullable = false)
    private Station sourceStation;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "destination_station_id", nullable = false)
    private Station destinationStation;
    // Rule "source != destination" is enforced by a CHECK constraint and, later, in the service.
}
