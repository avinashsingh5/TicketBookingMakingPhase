package com.railway.booking.payment;

public enum PaymentType {
    CHARGE, REFUND
}
