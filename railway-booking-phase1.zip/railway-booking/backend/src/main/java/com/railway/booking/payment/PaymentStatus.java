package com.railway.booking.payment;

public enum PaymentStatus {
    INITIATED, SUCCESS, FAILED
}
