package com.railway.booking.inventory;

import com.railway.booking.trip.Trip;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.math.BigDecimal;

/** A travel class (1AC, 2AC, 3AC, SL...) on one trip, with its fare and seat counter. */
@Entity
@Table(name = "trip_classes")
@Getter @Setter @NoArgsConstructor
public class TripClass {

    @Id @UuidGenerator
    @Column(name = "class_id", length = 36, updatable = false)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "trip_id", nullable = false)
    private Trip trip;

    @NotBlank
    @Column(name = "class_type", nullable = false, length = 10)
    private String classType;

    @NotNull @DecimalMin("0.00")
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal fare;

    /**
     * Fast-search counter. The real truth is trip_seats minus seat_assignments.
     * It is only changed inside the booking/cancellation transactions (never negative: DB CHECK).
     */
    @Min(0)
    @Column(name = "available_seats", nullable = false)
    private int availableSeats;
}
