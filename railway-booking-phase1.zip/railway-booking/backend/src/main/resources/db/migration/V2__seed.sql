-- =====================================================================
-- V2__seed.sql  -  Sample DEMO data for local development only.
-- Flyway applies this once to a fresh database, so restarting the app never duplicates rows.
-- (For a real deployment you would move this file out of db/migration.)
--
-- * Station/train IDs are fixed literals; trip/class/seat IDs are derived from MD5 hashes of
--   their natural keys, so the same input always gives the same UUID-shaped ID.
-- * Trips cover the 14 days AFTER the day the migration runs, so there is always future data.
-- * Schedule times below are Indian Standard Time (IST = UTC+05:30); they are stored as UTC.
-- * No users are seeded. The admin account is created at startup from environment variables
--   (ADMIN_EMAIL / ADMIN_PASSWORD) in the authentication phase, so no password is in git.
-- * Train numbers are made-up sample numbers, not real railway data.
-- =====================================================================

INSERT INTO stations (station_id, station_code, station_name, city, state, is_active) VALUES
('a1000000-0000-4000-8000-000000000001', 'NDLS', 'New Delhi',                'New Delhi', 'Delhi',       TRUE),
('a1000000-0000-4000-8000-000000000002', 'CSMT', 'Chhatrapati Shivaji Maharaj Terminus', 'Mumbai', 'Maharashtra', TRUE),
('a1000000-0000-4000-8000-000000000003', 'HWH',  'Howrah Junction',          'Kolkata',   'West Bengal', TRUE),
('a1000000-0000-4000-8000-000000000004', 'MAS',  'Chennai Central',          'Chennai',   'Tamil Nadu',  TRUE),
('a1000000-0000-4000-8000-000000000005', 'SBC',  'KSR Bengaluru City',       'Bengaluru', 'Karnataka',   TRUE),
('a1000000-0000-4000-8000-000000000006', 'ADI',  'Ahmedabad Junction',       'Ahmedabad', 'Gujarat',     TRUE),
('a1000000-0000-4000-8000-000000000007', 'JP',   'Jaipur Junction',          'Jaipur',    'Rajasthan',   TRUE),
('a1000000-0000-4000-8000-000000000008', 'PUNE', 'Pune Junction',            'Pune',      'Maharashtra', TRUE),
-- Inactive on purpose: lets us test that inactive stations are hidden from search.
('a1000000-0000-4000-8000-000000000009', 'GWL',  'Gwalior Junction',         'Gwalior',   'Madhya Pradesh', FALSE);

INSERT INTO trains (train_id, train_number, source_station_id, destination_station_id) VALUES
('b1000000-0000-4000-8000-000000000001', '90101', 'a1000000-0000-4000-8000-000000000001', 'a1000000-0000-4000-8000-000000000002'), -- NDLS -> CSMT
('b1000000-0000-4000-8000-000000000002', '90102', 'a1000000-0000-4000-8000-000000000002', 'a1000000-0000-4000-8000-000000000001'), -- CSMT -> NDLS
('b1000000-0000-4000-8000-000000000003', '90103', 'a1000000-0000-4000-8000-000000000001', 'a1000000-0000-4000-8000-000000000003'), -- NDLS -> HWH
('b1000000-0000-4000-8000-000000000004', '90104', 'a1000000-0000-4000-8000-000000000003', 'a1000000-0000-4000-8000-000000000001'), -- HWH  -> NDLS
('b1000000-0000-4000-8000-000000000005', '90105', 'a1000000-0000-4000-8000-000000000001', 'a1000000-0000-4000-8000-000000000007'), -- NDLS -> JP
('b1000000-0000-4000-8000-000000000006', '90106', 'a1000000-0000-4000-8000-000000000002', 'a1000000-0000-4000-8000-000000000008'), -- CSMT -> PUNE
('b1000000-0000-4000-8000-000000000007', '90107', 'a1000000-0000-4000-8000-000000000004', 'a1000000-0000-4000-8000-000000000005'), -- MAS  -> SBC
('b1000000-0000-4000-8000-000000000008', '90108', 'a1000000-0000-4000-8000-000000000006', 'a1000000-0000-4000-8000-000000000002'); -- ADI  -> CSMT

-- ---- Helper tables (temporary, vanish when the migration connection closes) ----
CREATE TEMPORARY TABLE seed_numbers (n INT NOT NULL PRIMARY KEY)
    DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO seed_numbers (n) VALUES
 (1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12),(13),(14),(15),(16),(17),(18),(19),(20),(21),(22),(23),(24);

-- Departure time (IST) and journey length for each sample train.
CREATE TEMPORARY TABLE seed_train_plan (
    train_number VARCHAR(10) NOT NULL PRIMARY KEY, dep_time_ist TIME NOT NULL, duration_min INT NOT NULL
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO seed_train_plan (train_number, dep_time_ist, duration_min) VALUES
 ('90101', '16:30:00', 960), ('90102', '17:00:00', 975), ('90103', '17:15:00', 1050), ('90104', '16:50:00', 1065),
 ('90105', '06:10:00', 290), ('90106', '07:00:00', 215),  ('90107', '21:30:00', 360),  ('90108', '22:15:00', 540);

-- Classes per train: coach prefix for seat numbers, fare in INR and how many seats to create.
CREATE TEMPORARY TABLE seed_class_plan (
    train_number VARCHAR(10) NOT NULL, class_type VARCHAR(10) NOT NULL, coach VARCHAR(4) NOT NULL,
    fare DECIMAL(12,2) NOT NULL, seat_count INT NOT NULL, PRIMARY KEY (train_number, class_type)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO seed_class_plan (train_number, class_type, coach, fare, seat_count) VALUES
 ('90101','1AC','H1',4200.00, 6), ('90101','2AC','A1',2500.00,12), ('90101','3AC','B1',1750.00,18), ('90101','SL','S1',680.00,24),
 ('90102','1AC','H1',4200.00, 6), ('90102','2AC','A1',2500.00,12), ('90102','3AC','B1',1750.00,18), ('90102','SL','S1',680.00,24),
 ('90103','2AC','A1',2300.00,12), ('90103','3AC','B1',1600.00,18), ('90103','SL','S1',620.00,24),
 ('90104','2AC','A1',2300.00,12), ('90104','3AC','B1',1600.00,18), ('90104','SL','S1',620.00,24),
 ('90105','3AC','B1', 780.00,18), ('90105','SL','S1',310.00,24),
 ('90106','2AC','A1', 950.00,12), ('90106','3AC','B1', 690.00,18),
 ('90107','2AC','A1',1200.00,12), ('90107','SL','S1',420.00,24),
 ('90108','3AC','B1',1100.00,18), ('90108','SL','S1',480.00,24);

-- ---- Trips: every train, each of the next 14 days ----
INSERT INTO trips (trip_id, train_id, departure_at, arrival_at, status)
SELECT CONCAT(SUBSTR(x.h,1,8),'-',SUBSTR(x.h,9,4),'-',SUBSTR(x.h,13,4),'-',SUBSTR(x.h,17,4),'-',SUBSTR(x.h,21,12)),
       x.train_id, x.dep_utc, x.dep_utc + INTERVAL x.duration_min MINUTE, 'SCHEDULED'
FROM (
    SELECT MD5(CONCAT('trip:', t.train_number, ':', d.n)) AS h,
           t.train_id,
           TIMESTAMP(DATE_ADD(CURRENT_DATE, INTERVAL d.n DAY), p.dep_time_ist) - INTERVAL 330 MINUTE AS dep_utc,
           p.duration_min
    FROM trains t
    JOIN seed_train_plan p ON p.train_number = t.train_number
    JOIN seed_numbers d    ON d.n <= 14
) x;

-- ---- Classes for each trip (available_seats starts equal to the number of seats created below) ----
INSERT INTO trip_classes (class_id, trip_id, class_type, fare, available_seats)
SELECT CONCAT(SUBSTR(x.h,1,8),'-',SUBSTR(x.h,9,4),'-',SUBSTR(x.h,13,4),'-',SUBSTR(x.h,17,4),'-',SUBSTR(x.h,21,12)),
       x.trip_id, x.class_type, x.fare, x.seat_count
FROM (
    SELECT MD5(CONCAT('class:', tr.trip_id, ':', cp.class_type)) AS h,
           tr.trip_id, cp.class_type, cp.fare, cp.seat_count
    FROM trips tr
    JOIN trains t           ON t.train_id = tr.train_id
    JOIN seed_class_plan cp ON cp.train_number = t.train_number
) x;

-- ---- Seats for each class: e.g. B1-1 ... B1-18 ----
INSERT INTO trip_seats (seat_id, class_id, seat_number)
SELECT CONCAT(SUBSTR(x.h,1,8),'-',SUBSTR(x.h,9,4),'-',SUBSTR(x.h,13,4),'-',SUBSTR(x.h,17,4),'-',SUBSTR(x.h,21,12)),
       x.class_id, CONCAT(x.coach, '-', x.n)
FROM (
    SELECT MD5(CONCAT('seat:', tc.class_id, ':', s.n)) AS h, tc.class_id, cp.coach, s.n
    FROM trip_classes tc
    JOIN trips tr           ON tr.trip_id = tc.trip_id
    JOIN trains t           ON t.train_id = tr.train_id
    JOIN seed_class_plan cp ON cp.train_number = t.train_number AND cp.class_type = tc.class_type
    JOIN seed_numbers s     ON s.n <= cp.seat_count
) x;

DROP TEMPORARY TABLE seed_numbers;
DROP TEMPORARY TABLE seed_train_plan;
DROP TEMPORARY TABLE seed_class_plan;
