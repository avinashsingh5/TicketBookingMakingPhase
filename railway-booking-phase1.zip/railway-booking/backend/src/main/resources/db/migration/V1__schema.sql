-- =====================================================================
-- V1__schema.sql  -  Railway Ticket Booking System (Phase 1)
-- MySQL 8. All IDs are UUID strings stored as CHAR(36).
-- All timestamps are DATETIME(6) and are stored in UTC.
-- Status/role columns are VARCHAR + CHECK (simple to map with JPA enums).
--
-- Creation order follows the foreign-key dependencies:
--   users, stations -> trains -> trips -> trip_classes -> trip_seats
--   -> reservations -> tickets -> seat_assignments
--   -> cancellation_requests -> cancellation_items -> payments
-- There is NO circular dependency:  seat_assignments points to tickets,
-- but tickets point to trip_seats (not to seat_assignments).
-- =====================================================================

-- ---------------------------- USER DOMAIN ----------------------------
CREATE TABLE users (
    user_id        CHAR(36)     NOT NULL,
    name           VARCHAR(100) NOT NULL,
    email          VARCHAR(255) NOT NULL,
    password_hash  VARCHAR(100) NOT NULL,               -- BCrypt hash only (60 chars)
    role           VARCHAR(20)  NOT NULL,
    created_at     DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (user_id),
    UNIQUE KEY uk_users_email (email),
    CONSTRAINT ck_users_role CHECK (role IN ('CUSTOMER', 'ADMIN'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------- TRAIN DOMAIN ---------------------------
CREATE TABLE stations (
    station_id    CHAR(36)     NOT NULL,
    station_code  VARCHAR(10)  NOT NULL,
    station_name  VARCHAR(100) NOT NULL,
    city          VARCHAR(100) NOT NULL,
    state         VARCHAR(100) NOT NULL,
    is_active     BOOLEAN      NOT NULL DEFAULT TRUE,
    PRIMARY KEY (station_id),
    UNIQUE KEY uk_stations_code (station_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE trains (
    train_id               CHAR(36)    NOT NULL,
    train_number           VARCHAR(10) NOT NULL,
    source_station_id      CHAR(36)    NOT NULL,
    destination_station_id CHAR(36)    NOT NULL,
    PRIMARY KEY (train_id),
    UNIQUE KEY uk_trains_number (train_number),
    KEY idx_trains_source (source_station_id),
    KEY idx_trains_destination (destination_station_id),
    CONSTRAINT fk_trains_source      FOREIGN KEY (source_station_id)      REFERENCES stations (station_id),
    CONSTRAINT fk_trains_destination FOREIGN KEY (destination_station_id) REFERENCES stations (station_id),
    CONSTRAINT ck_trains_diff_stations CHECK (source_station_id <> destination_station_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE trips (
    trip_id       CHAR(36)    NOT NULL,
    train_id      CHAR(36)    NOT NULL,
    departure_at  DATETIME(6) NOT NULL,
    arrival_at    DATETIME(6) NOT NULL,
    status        VARCHAR(20) NOT NULL,
    PRIMARY KEY (trip_id),
    UNIQUE KEY uk_trips_train_departure (train_id, departure_at),   -- also indexes train_id (FK)
    KEY idx_trips_departure_status (departure_at, status),          -- date search
    CONSTRAINT fk_trips_train FOREIGN KEY (train_id) REFERENCES trains (train_id),
    CONSTRAINT ck_trips_status CHECK (status IN ('SCHEDULED', 'COMPLETED', 'CANCELLED')),
    CONSTRAINT ck_trips_times  CHECK (arrival_at > departure_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE trip_classes (
    class_id         CHAR(36)      NOT NULL,
    trip_id          CHAR(36)      NOT NULL,
    class_type       VARCHAR(10)   NOT NULL,
    fare             DECIMAL(12,2) NOT NULL,
    -- Denormalised counter for fast search. Authoritative data = trip_seats + seat_assignments.
    -- Invariant: available_seats = (seats in class) - (rows in seat_assignments for those seats).
    available_seats  INT           NOT NULL,
    PRIMARY KEY (class_id),
    UNIQUE KEY uk_trip_classes_trip_type (trip_id, class_type),     -- also indexes trip_id (FK)
    CONSTRAINT fk_trip_classes_trip FOREIGN KEY (trip_id) REFERENCES trips (trip_id),
    CONSTRAINT ck_trip_classes_fare  CHECK (fare >= 0),
    CONSTRAINT ck_trip_classes_avail CHECK (available_seats >= 0)   -- never negative, enforced by the DB
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE trip_seats (
    seat_id      CHAR(36)    NOT NULL,
    class_id     CHAR(36)    NOT NULL,
    seat_number  VARCHAR(20) NOT NULL,
    PRIMARY KEY (seat_id),
    UNIQUE KEY uk_trip_seats_class_number (class_id, seat_number),  -- also indexes class_id (FK)
    CONSTRAINT fk_trip_seats_class FOREIGN KEY (class_id) REFERENCES trip_classes (class_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------- RESERVATION DOMAIN -----------------------
CREATE TABLE reservations (
    reservation_id  CHAR(36)      NOT NULL,
    user_id         CHAR(36)      NOT NULL,
    class_id        CHAR(36)      NOT NULL,
    pnr             VARCHAR(10)   NULL,                  -- generated only after payment succeeds
    status          VARCHAR(30)   NOT NULL,
    total_amount    DECIMAL(12,2) NOT NULL,              -- original booking amount, never overwritten
    created_at      DATETIME(6)   NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    confirmed_at    DATETIME(6)   NULL,
    PRIMARY KEY (reservation_id),
    UNIQUE KEY uk_reservations_pnr (pnr),                -- MySQL allows many NULLs in a unique index
    KEY idx_reservations_user_created (user_id, created_at),
    KEY idx_reservations_class (class_id),
    CONSTRAINT fk_reservations_user  FOREIGN KEY (user_id)  REFERENCES users (user_id),
    CONSTRAINT fk_reservations_class FOREIGN KEY (class_id) REFERENCES trip_classes (class_id),
    CONSTRAINT ck_reservations_status CHECK (status IN ('PENDING_PAYMENT', 'CONFIRMED', 'PARTIALLY_CANCELLED', 'CANCELLED')),
    CONSTRAINT ck_reservations_total  CHECK (total_amount >= 0),
    -- A confirmed (or partly cancelled) booking must always have a PNR and a confirmation time.
    CONSTRAINT ck_reservations_pnr_when_confirmed CHECK (
        status NOT IN ('CONFIRMED', 'PARTIALLY_CANCELLED') OR (pnr IS NOT NULL AND confirmed_at IS NOT NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE tickets (
    ticket_id         CHAR(36)      NOT NULL,
    reservation_id    CHAR(36)      NOT NULL,
    passenger_name    VARCHAR(100)  NOT NULL,
    passenger_age     INT           NOT NULL,
    passenger_gender  VARCHAR(20)   NOT NULL,
    -- NOT unique on purpose: a cancelled ticket keeps its historical seat even after
    -- the seat is given to a new ticket. Current ownership lives in seat_assignments.
    seat_id           CHAR(36)      NULL,
    fare_paid         DECIMAL(12,2) NOT NULL,            -- fare snapshot at booking time
    status            VARCHAR(20)   NOT NULL,
    created_at        DATETIME(6)   NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (ticket_id),
    KEY idx_tickets_reservation (reservation_id),
    KEY idx_tickets_seat (seat_id),
    CONSTRAINT fk_tickets_reservation FOREIGN KEY (reservation_id) REFERENCES reservations (reservation_id),
    CONSTRAINT fk_tickets_seat        FOREIGN KEY (seat_id)        REFERENCES trip_seats (seat_id),
    CONSTRAINT ck_tickets_status CHECK (status IN ('PENDING', 'CONFIRMED', 'CANCELLED')),
    CONSTRAINT ck_tickets_age    CHECK (passenger_age BETWEEN 0 AND 120),
    CONSTRAINT ck_tickets_fare   CHECK (fare_paid >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Current hold / allocation only. seat_id is the PRIMARY KEY, so a seat can have at most
-- ONE row here: that is what makes double allocation impossible at the database level.
CREATE TABLE seat_assignments (
    seat_id          CHAR(36)    NOT NULL,
    reservation_id   CHAR(36)    NOT NULL,
    ticket_id        CHAR(36)    NULL,                   -- filled once the ticket row exists
    status           VARCHAR(20) NOT NULL,
    hold_expires_at  DATETIME(6) NULL,
    PRIMARY KEY (seat_id),
    UNIQUE KEY uk_seat_assignments_ticket (ticket_id),
    KEY idx_seat_assignments_reservation (reservation_id),
    KEY idx_seat_assignments_expiry (status, hold_expires_at),   -- expired-hold sweeper
    CONSTRAINT fk_seat_assignments_seat        FOREIGN KEY (seat_id)        REFERENCES trip_seats (seat_id),
    CONSTRAINT fk_seat_assignments_reservation FOREIGN KEY (reservation_id) REFERENCES reservations (reservation_id),
    CONSTRAINT fk_seat_assignments_ticket      FOREIGN KEY (ticket_id)      REFERENCES tickets (ticket_id),
    CONSTRAINT ck_seat_assignments_status CHECK (status IN ('HELD', 'CONFIRMED')),
    CONSTRAINT ck_seat_assignments_hold   CHECK (status <> 'HELD' OR hold_expires_at IS NOT NULL)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------- CANCELLATION DOMAIN ----------------------
CREATE TABLE cancellation_requests (
    cancel_request_id  CHAR(36)    NOT NULL,
    reservation_id     CHAR(36)    NOT NULL,
    status             VARCHAR(20) NOT NULL,
    requested_at       DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    completed_at       DATETIME(6) NULL,
    PRIMARY KEY (cancel_request_id),
    KEY idx_cancel_requests_reservation (reservation_id),
    CONSTRAINT fk_cancel_requests_reservation FOREIGN KEY (reservation_id) REFERENCES reservations (reservation_id),
    CONSTRAINT ck_cancel_requests_status CHECK (status IN ('PENDING', 'COMPLETED', 'FAILED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE cancellation_items (
    cancel_item_id     CHAR(36)      NOT NULL,
    cancel_request_id  CHAR(36)      NOT NULL,
    ticket_id          CHAR(36)      NOT NULL,
    refund_amount      DECIMAL(12,2) NOT NULL,
    PRIMARY KEY (cancel_item_id),
    UNIQUE KEY uk_cancel_items_request_ticket (cancel_request_id, ticket_id),  -- also indexes cancel_request_id (FK)
    KEY idx_cancel_items_ticket (ticket_id),
    CONSTRAINT fk_cancel_items_request FOREIGN KEY (cancel_request_id) REFERENCES cancellation_requests (cancel_request_id),
    CONSTRAINT fk_cancel_items_ticket  FOREIGN KEY (ticket_id)         REFERENCES tickets (ticket_id),
    CONSTRAINT ck_cancel_items_refund CHECK (refund_amount >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------- PAYMENT DOMAIN --------------------------
CREATE TABLE payments (
    payment_id         CHAR(36)      NOT NULL,
    reservation_id     CHAR(36)      NOT NULL,
    cancel_request_id  CHAR(36)      NULL,               -- NULL for charges, set for refunds
    gateway_ref        VARCHAR(100)  NULL,
    idempotency_key    VARCHAR(100)  NOT NULL,
    amount             DECIMAL(12,2) NOT NULL,
    payment_type       VARCHAR(20)   NOT NULL,
    status             VARCHAR(20)   NOT NULL,
    created_at         DATETIME(6)   NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at         DATETIME(6)   NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (payment_id),
    UNIQUE KEY uk_payments_idempotency (idempotency_key),
    UNIQUE KEY uk_payments_gateway_ref (gateway_ref),
    KEY idx_payments_reservation (reservation_id),
    KEY idx_payments_cancel_request (cancel_request_id),
    CONSTRAINT fk_payments_reservation    FOREIGN KEY (reservation_id)    REFERENCES reservations (reservation_id),
    CONSTRAINT fk_payments_cancel_request FOREIGN KEY (cancel_request_id) REFERENCES cancellation_requests (cancel_request_id),
    CONSTRAINT ck_payments_type   CHECK (payment_type IN ('CHARGE', 'REFUND')),
    CONSTRAINT ck_payments_status CHECK (status IN ('INITIATED', 'SUCCESS', 'FAILED')),
    CONSTRAINT ck_payments_amount CHECK (amount >= 0),
    CONSTRAINT ck_payments_refund_link CHECK (
        (payment_type = 'CHARGE' AND cancel_request_id IS NULL) OR
        (payment_type = 'REFUND' AND cancel_request_id IS NOT NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------ CONSISTENCY CHECK VIEW ---------------------
-- Not a table. Lists classes whose counter disagrees with real seat data:
--   SELECT * FROM v_class_availability_check WHERE is_consistent = 0;   -- should return no rows
CREATE VIEW v_class_availability_check AS
SELECT tc.class_id,
       tc.available_seats AS counter_value,
       (SELECT COUNT(*) FROM trip_seats s WHERE s.class_id = tc.class_id) AS total_seats,
       (SELECT COUNT(*) FROM trip_seats s
          JOIN seat_assignments sa ON sa.seat_id = s.seat_id
         WHERE s.class_id = tc.class_id) AS assigned_seats,
       (SELECT COUNT(*) FROM trip_seats s WHERE s.class_id = tc.class_id)
       - (SELECT COUNT(*) FROM trip_seats s
            JOIN seat_assignments sa ON sa.seat_id = s.seat_id
           WHERE s.class_id = tc.class_id) AS expected_available,
       CASE WHEN tc.available_seats =
            (SELECT COUNT(*) FROM trip_seats s WHERE s.class_id = tc.class_id)
          - (SELECT COUNT(*) FROM trip_seats s
               JOIN seat_assignments sa ON sa.seat_id = s.seat_id
              WHERE s.class_id = tc.class_id) THEN 1 ELSE 0 END AS is_consistent
FROM trip_classes tc;
