# Railway Ticket Booking System

Spring Boot 3 + MySQL 8 + React. **Status: Phase 1 (Foundation) done** — schema, seed data, entities, local MySQL.
The full README (architecture, ER diagram, API docs, workflows) is written in the last phase.

## Run it (Phase 1)

Requirements: Java 17+, Maven, Docker.

```bash
cp .env.example .env              # then edit the passwords
docker compose up -d              # starts MySQL 8 on 127.0.0.1:3306
docker compose ps                 # wait until it shows "healthy"

cd backend
mvn spring-boot:run               # Flyway creates the schema and seeds demo data on first start
```

The app reads DB credentials from the `.env` file in the repo root (or from real environment variables).
Check: `curl http://localhost:8080/actuator/health` should return `{"status":"UP"}`.

Inspect the data:

```bash
docker exec -it railway-mysql mysql -u railway_user -p railway_booking
mysql> SELECT station_code, is_active FROM stations;
mysql> SELECT * FROM v_class_availability_check WHERE is_consistent = 0;   -- must return no rows
```

Reset to a fresh database: `docker compose down -v && docker compose up -d`.

## Phase 1 design notes

- **Migrations:** `V1__schema.sql` (14 tables + one consistency view), `V2__seed.sql` (demo data). Flyway runs each once, so restarts never duplicate data.
- **Seat uniqueness:** `seat_assignments.seat_id` is the primary key, so the database itself refuses a second active assignment for a seat.
- **Ticket history:** `tickets.seat_id` is *not* unique; cancelled tickets keep their old seat.
- **Counter safety:** `trip_classes.available_seats` has `CHECK (>= 0)`. The view `v_class_availability_check` compares it with real seat rows.
- **Admin account:** not in SQL. It will be created at startup from `ADMIN_EMAIL` / `ADMIN_PASSWORD` (authentication phase).
- **Time zone:** all timestamps are UTC. Seed schedules are written in IST and converted to UTC.
